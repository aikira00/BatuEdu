
import java.net.*;
import java.io.*;

// eccezione specifica della classe CalculatorClient
class CalculatorException extends Exception {
}

public class CalculatorClient {
    private String server_name;
    private int server_port;

    public CalculatorClient(String server, int port) throws IOException {
        server_name = server;
        server_port = port;
    }
    
    private double request(String operation, double x, double y) throws CalculatorException, SocketTimeoutException, IOException  {
        InputStream input;
        OutputStreamWriter output;
        String operand1;
        String operand2;
        String command;
        String character;
        int i, n;
        byte [] buffer = new byte[1024];
        StringBuffer answer = new StringBuffer();
        Socket client_socket = new Socket();
        InetSocketAddress server_address = new InetSocketAddress(server_name, server_port);
        // conversione degli operandi numerici in formato stringa
        operand1 = Double.toString(x);
        operand2 = Double.toString(y);
        // richiesta di connessione al server (attesa massima 1s)
        client_socket.connect(server_address, 1000); // 1000ms = 1s        
        // stream di input per ricezione dati dal server
        input = client_socket.getInputStream();
        // stream di output per l’invio di dati al server
        output = new OutputStreamWriter(client_socket.getOutputStream());
        // costruzione stringa di commando
        command = operation + "," + operand1 + "," + operand2;
        // invio della stringa di commando terminata al server
        output.write(command +"\r\n");
        output.flush();
        client_socket.setSoTimeout(1000); // 1000ms = 1s
        // ciclo di ricezione dei dati dal client
        while ((n = input.read(buffer)) != -1) {
            if (n > 0) {
            	// ricerca dei caratteri di terminazione
            	for (i=0; i<n; i++) {
                    if (buffer[i] == '\r' || buffer[i] == '\n') {
                        // risposta ricevuta: chiusura connessione
                        input.close();
                        output.close();
                        client_socket.close();
                        // se risposta di errore -> generazione eccezione specifica
                        if (answer.toString().
                            equalsIgnoreCase("ERROR")) {
                            throw new CalculatorException();
                        }
                        else {                              
                        	// conversione risposta in risultato numerico
                        	return Double.parseDouble(answer.toString());
                        }
                    }
                    else {
                        // trasformazione dei caratteri ricevuti in formato Unicode e costruzione della risposta carattere per carattere
                        character = new String(buffer, i, 1, "ISO-8859-1");
                        answer.append(character);
                    }
                }
            }
        }
        // in caso di errore chiusura degli stream di comunicazione e del socket di connessione al server
        input.close();
        output.close();
        client_socket.close();
        throw new IOException();
    }
    
    // addizione
    public double add(double x, double y) throws CalculatorException, SocketTimeoutException, IOException  {
        return request("ADD", x, y);
    }
    // sottrazione
    public double sub(double x, double y) throws CalculatorException, SocketTimeoutException, IOException  {
        return request("SUB", x, y);
    }
    // moltiplicazione
    public double mul(double x, double y) throws CalculatorException, SocketTimeoutException, IOException  {
        return request("MUL", x, y);
    }
    // divisione
    public double div(double x, double y) throws CalculatorException, SocketTimeoutException, IOException  {
        return request("DIV", x, y);
    }
    
    public static void main(String args[]) throws IOException {
        String server;
        int port;
        double z;
        CalculatorClient client;
    
        if (args.length != 2) {
            System.err.println("Errore nei parametri!");
        }
        else {
        	server = args[0];
                port = Integer.parseInt(args[1]);
                try {
                    client = new CalculatorClient(server, port);
                    z = client.add(1.5, -0.5);
                    System.out.println(z);
                    z = client.sub(1.5, -0.5);
                    System.out.println(z);
                    z = client.mul(1.5, 2.0);
                    System.out.println(z);
                    z = client.div(-8.0, -2.0);
                    System.out.println(z);
                    z = client.div(1, 0.0);
        	}
        	catch (CalculatorException exception) {
                    System.err.println("Errore di calcolo!");
        	}
        	catch (SocketTimeoutException exception) {
                    System.err.println("Nessuna risposta dal server!");
        	}
        	catch (IOException exception) {
                    System.err.println("Errore generico di comunicazione!");
                }
        }
    }
}
