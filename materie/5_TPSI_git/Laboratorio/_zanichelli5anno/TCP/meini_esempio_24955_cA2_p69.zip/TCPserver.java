
import java.io.*;
import java.net.*;
import java.util.concurrent.*;

public class TCPserver extends Thread {
 public final static int SERVER_PORT = 12345;
 public final static int MAX_CLIENT = 10;
 private ServerSocket server;
 private ExecutorService threads;
    
 public TCPserver(int port) throws IOException {
  server = new ServerSocket(port);
  server.setSoTimeout(1000); // 1000ms = 1s
  threads = Executors.newFixedThreadPool(MAX_CLIENT); // thread-pool limitato
 }
    
 public void run() {
  Socket connection = null;
        
  while (!Thread.interrupted()) {
   try {
    connection = server.accept(); // attesa richiesta connessione da parte del client (attesa massima 1s)
    ClientThread client_thread = new ClientThread(connection);
    try {
        threads.submit(client_thread);
    }
    catch (RejectedExecutionException exception) {
        // nel caso di impossibilità a gestire il client chiusura della connessione
        connection.close();
    }
   }
   catch (SocketTimeoutException exception) { }
   catch (IOException exception) { }
  }
  // chiusura socket di ascolto del server 
  try {
   server.close();
   threads.shutdown();
  }
  catch (IOException exception) {
  }
 }
public static void main(String[] args) {
  int c;
        
  try {
   TCPserver server;

   server = new TCPserver(SERVER_PORT);
   server.start();
   c = System.in.read();
   server.interrupt();
   server.join();
  }
  catch (IOException exception) {
   System.err.println("Errore!");
  }
  catch (InterruptedException exception) {
   System.err.println("Fine!");
  }
 }
}
