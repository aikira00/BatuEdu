
import java.io.*;
import java.net.*;
import java.util.concurrent.*;

public class ClientThread implements Runnable {
 private Socket connection; // socket di connessione con il client
 private InputStream input; // stream di input del socket
 private OutputStreamWriter output; // stream di output del socket
    
 public ClientThread(Socket connection) throws IOException {
  this.connection = connection;
  input = this.connection.getInputStream();
  output = new OutputStreamWriter(this.connection.getOutputStream());
 }
 
 // metodo che a partire dalla stringa di comando ricevuta dal client restituisce la stringa di risposta
    private String calculator(String command) {
        String result; String component[];
        double x, y, z = 0.0;
        
        component = command.split(","); // separazione della stringa nelle tre component
        if (component.length != 3) { return "ERROR"; }
        // conversione in formato numerico degli operandi
        try {
            x = Double.parseDouble(component[1]); y = Double.parseDouble(component[2]);
        }
        catch (NumberFormatException exception) {
            return "ERROR";
        }
        // determinazione dell’operazione da eseguire
        if (component[0].equalsIgnoreCase("ADD")) { z = x + y; } // addizione
        else if (component[0].equalsIgnoreCase("SUB")) { z = x - y; } // sottrazione
        else if (component[0].equalsIgnoreCase("MUL")) { z = x * y; } // moltiplicazione
        else if (component[0].equalsIgnoreCase("DIV")) {
            if (y == 0.0) { return "ERROR"; } // divisione per 0
            else { z = x / y; } // divisione
        }
        else { return "ERROR"; } // operazione non valida
        result = Double.toString(z); // conversione in stringa del risultato
        return result;
    }

 public void run() {
     int n, i;
        String result; String character;
        byte [] buffer = new byte[1024];
        StringBuffer command = new StringBuffer();
        try {
             while ((n = input.read(buffer)) != -1) { // ciclo di ricezione dei dati dal client
                if (n > 0) {
			for (i=0; i<n; i++) { // ricerca dei caratteri di terminazione 
                        if (buffer[i] == '\r' || buffer[i] == '\n') { // commando ricevuto -> esecuzione
			        result = calculator(command.toString());
			        output.  write(result+"\r\n"); output.flush(); // invio al client del risultato
			        command = new StringBuffer(); // inizializzazione del comando
                            break;
                        }
                        else { character = new String(buffer, i, 1, "ISO-8859-1"); command.append(character); }
                    }
                }
            }
        }
        catch (IOException exception) { }
 
        try {
            System.out.println("Connessione chiusa!");
            input.close(); output.close();
            connection.shutdownInput(); connection.shutdownOutput(); connection.close(); 
        }
        catch (IOException _exception) { }
    }
}

