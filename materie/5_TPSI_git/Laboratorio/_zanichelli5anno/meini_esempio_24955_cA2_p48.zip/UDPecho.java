import java.net.*;
import java.io.*;


public class UDPecho extends Thread {
 private DatagramSocket socket;
 
 public UDPecho(int port) throws SocketException {
  socket = new DatagramSocket(port);
  socket.setSoTimeout(1000); // 1000ms = 1s
 }

 public void run() {
  DatagramPacket answer;
  
  // creazione di un array di byte della dimensione specificata
  byte[] buffer = new byte[8192];
  // creazione di un datagram UDP a partire dall'array di byte
  DatagramPacket request = new DatagramPacket(buffer, buffer.length);
  while (!Thread.interrupted()) {
   try {
    // attesa ricezione datagram di richiesta tempo massimo di attesa: 1s
    socket.receive(request);
    // costruzione datagram di risposta (identico al datagram di richiesta)
    answer = new DatagramPacket( request.getData(), request.getLength(),
    request.getAddress(), request.getPort());
    // trasmissione datagram di risposta
    socket.send(answer);
   }
   catch (IOException exception) {
   }
  }
  socket.close(); // chiusura del socket
 }

 public static void main(String[] args) {
  int c; 

  try {
   UDPecho echoserver = new UDPecho(7);
   echoserver.start();
   c = System.in.read();
   echoserver.interrupt();
   echoserver.join();
  }
  catch (IOException exception) {
   System.err.println("Errore!");
  }
  catch (InterruptedException exception) {
   System.err.println("Fine.");
  }
 }
}
