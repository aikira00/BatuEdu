
import java.net.*;
import java.io.*;

public class ClientThread implements Runnable {
    private Socket connection;
    private InputStream input; private OutputStreamWriter output;
    private TrackedCustomers tracked_customers;
        
    public ClientThread(Socket connection, TrackedCustomers tracked_customers) throws IOException {
        this.connection = connection;
        this.tracked_customers = tracked_customers;
        input = this.connection.getInputStream();
        output = new OutputStreamWriter(this.connection.getOutputStream());
    }
    
    // metodo che a partire dalla stringa di comando ricevuta dal client restituisce la stringa di risposta
    private String protocol(String command) {
       String result;
       String component[];
       long random_code, tag_code;
        
        component = command.split(","); // separazione della stringa nelle component
        if (component.length < 1) {
            return "ERROR";
        }
        // determinazione dell’operazione da eseguire
        if (component[0].equalsIgnoreCase("CODE")) {
            random_code = tracked_customers.newCustomer();
            result = "OK," + Long.toString(random_code);
        }
        else if (component[0].equalsIgnoreCase("TAG")) {
            if (component.length < 3) {
                return "ERROR";
            }
            try {
                random_code = Long.parseLong(component[1]);
                tag_code = Long.parseLong(component[2]);
            }
            catch ( NumberFormatException exception) {
                return "ERROR";
            }
            try {
                tracked_customers.newCustomerTag(random_code, tag_code);
            }
            catch (CustomerNotFoundException exception) {
                return "ERROR";
            }
            result = "OK";
        }
        else {
            return "ERROR";
        } // comando non valido
        return result;
    }
    
    public void run()  {
        int n, i;
        String result; String character;
        byte [] buffer = new byte[1024];
        StringBuffer command = new StringBuffer();

        try {
             while ((n = input.read(buffer)) != -1) { // ciclo di ricezione dei dati dal client
                if (n > 0) {
			for (i=0; i<n; i++) { // ricerca dei caratteri di terminazione 
                        if (buffer[i] == '\r' || buffer[i] == '\n') { // commando ricevuto -> esecuzione
			        result = protocol(command.toString());
			        output.write(result+"\r\n"); output.flush(); // invio al client del risultato
			        command = new StringBuffer(); // inizializzazione del comando
                            break;
                        }
                        else { character = new String(buffer, i, 1, "ISO-8859-1"); command.append(character); }
                    }
                }
            }
        }
        catch (IOException exception) {
        }
        try {
            input.close(); output.close();
            connection.shutdownInput(); connection.shutdownOutput(); connection.close(); 
        }
        catch (IOException _exception) { }
    }
}
