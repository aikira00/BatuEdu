
import java.util.*;

public class CodeGenerator {
    private Random random;
    
    public CodeGenerator() {
        random = new Random();
    }
    
    public long getCode() {
        long tmp = random.nextLong();
        return (tmp<0 ? -tmp : tmp);
    }
}
