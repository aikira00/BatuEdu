
import java.util.*;
import java.io.*;
import java.util.concurrent.*;


public class TrackedCustomers {
    private ConcurrentHashMap<Long, Customer> customer_map;
    private CodeGenerator code_generator;
        
    public TrackedCustomers() {
        customer_map = new ConcurrentHashMap<>();
        code_generator = new CodeGenerator();
    }
    
    public synchronized long newCustomer() {
        long random_code = code_generator.getCode();
        Customer customer = new Customer(random_code);
       
        customer_map.put(random_code, customer);
        return random_code;
    }
    
    public synchronized void newCustomerTag(long random_code, long tag_code) throws CustomerNotFoundException {
       if (!customer_map.containsKey(random_code))
            throw new CustomerNotFoundException();
            customer_map.get(random_code).newTag(tag_code);
       return;
    }
    
    public synchronized void saveToFile(String filename) throws IOException {
        String line;
        FileWriter file = new FileWriter(filename);
        
        for (Iterator<Customer> iterator = customer_map.values().iterator(); iterator.hasNext();) {
                line = iterator.next().ToString();
                file.write(line);
                file.write("\r\n");
            }
        file.close();
        return;
    }
}
