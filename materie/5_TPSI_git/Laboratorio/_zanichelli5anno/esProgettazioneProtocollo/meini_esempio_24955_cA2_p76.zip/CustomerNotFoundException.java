
public class CustomerNotFoundException extends java.lang.Exception {
}
