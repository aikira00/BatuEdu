
import java.util.*;

public class Customer {
    private long random_code;
    private ArrayList<Long> tag_list;
    
    public Customer(long random_code) {
        this.random_code = random_code;
        tag_list = new ArrayList<>();
    }
    
    public Customer(Customer customer) {
        long[] tags = customer.getTagList();
        
        random_code = customer.getRandomCode();
        for (int i=0; i<tags.length; i++)
            newTag(tags[i]);
    }
    
    public void newTag(long tag_code) {
        tag_list.add(tag_code);
        return;
    }
    
    public long getRandomCode() {
        return random_code;
    }
    
    public long[] getTagList() {
        long[] tags = new long[tag_list.size()];
        int i = 0;
        
        for (Iterator<Long> iterator = tag_list.iterator(); iterator.hasNext();) {
            tags[i] = iterator.next();
            i++;
        }
        return tags;
    }
    
    public String ToString() {
        String string = Long.toString(random_code);
        for (Iterator<Long> iterator = tag_list.iterator(); iterator.hasNext();) {
            string = string + "," + iterator.next().toString();
        }
        return string;
    }
}
