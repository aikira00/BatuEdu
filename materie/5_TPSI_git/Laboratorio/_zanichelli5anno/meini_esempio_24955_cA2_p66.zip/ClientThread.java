
import java.io.*;
import java.net.*;

public class ClientThread extends Thread {
 private Socket connection; // socket di connessione con il client
 private InputStream input; // stream di input del socket
 private OutputStream output; // stream di output del socket
    
 public ClientThread(Socket connection) throws IOException {
  this.connection = connection;
  input = this.connection.getInputStream();
  output = this.connection.getOutputStream();
 }
    
 public void run() {
  int n;
  byte[] buffer = new byte[1024];
        
  try {
    while ((n = input.read(buffer)) != -1) {
     if (n > 0) { output.write(buffer, 0, n); output.flush(); }
   }
  }
  catch (IOException exception) { }
  try {
   System.out.println("Connessione chiusa!");
   input.close(); output.close();
   connection.shutdownInput(); connection.shutdownOutput();
   connection.close();
  }
  catch (IOException _exception) { }
 }
}