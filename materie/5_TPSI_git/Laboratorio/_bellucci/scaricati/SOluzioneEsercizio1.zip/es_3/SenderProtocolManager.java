package es_3;

import io.Sender;
public class SenderProtocolManager implements ISenderProtocol {
    private Sender sender;

    public SenderProtocolManager(Sender sender){
        this.sender = sender;
    }

    @Override
    public void prepareMessage(String operator, int op1, int op2, int res){
        String message = op1 + operator + op2 + '=' + res;
        sender.send(message);
    }

    @Override
    public void close(){
        sender.close();
    }
}