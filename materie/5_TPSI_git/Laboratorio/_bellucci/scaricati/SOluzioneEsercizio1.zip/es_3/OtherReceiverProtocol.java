package es_3;

import io.IMessageConsumer;

public class OtherReceiverProtocol implements IMessageConsumer {

    private INewCommandConsumer consumer;

    public OtherReceiverProtocol(INewCommandConsumer consumer) {
        this.consumer = consumer;
    }

    @Override
    public void consumeMessage(String message) {
        if (!message.equals("quit")) {
            String[] array = message.split("XX");

            switch (array[1]) {
                case "+":
                    consumer.add(array[1], Integer.parseInt(array[0]), Integer.parseInt(array[2]));
                    break;
                case "-":
                    consumer.sub(array[1], Integer.parseInt(array[0]), Integer.parseInt(array[2]));
                    break;
                case "*":
                    consumer.mul(array[1], Integer.parseInt(array[0]), Integer.parseInt(array[2]));
                    break;
                case "/":
                    consumer.div(array[1], Integer.parseInt(array[0]), Integer.parseInt(array[2]));
                    break;
            }
        } else {
            consumer.close();
        }
    }

}
