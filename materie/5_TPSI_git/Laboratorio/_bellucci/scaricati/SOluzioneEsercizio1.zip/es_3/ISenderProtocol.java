/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package es_3;

/**
 *
 * @author MULTI01
 */
public interface ISenderProtocol {

    void close();

    void prepareMessage(String operator, int op1, int op2, int res);
    
}
