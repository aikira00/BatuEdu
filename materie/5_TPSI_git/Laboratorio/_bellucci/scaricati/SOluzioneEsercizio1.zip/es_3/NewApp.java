/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package es_3;

/**
 *
 * @author MULTI01
 */
public class NewApp implements INewCommandConsumer{

    ISenderProtocol senderProtocol;

    public NewApp(ISenderProtocol senderProtocol) {
        this.senderProtocol = senderProtocol;
    }
    
    @Override
    public void add(String operator, int op1, int op2) {
        senderProtocol.prepareMessage(operator, op1, op2, op1+op2);
    }

    @Override
    public void sub(String operator, int op1, int op2) {
        senderProtocol.prepareMessage(operator, op1, op2, op1-op2);
    }

    @Override
    public void mul(String operator, int op1, int op2) {
        senderProtocol.prepareMessage(operator, op1, op2, op1*op2);
    }

    @Override
    public void div(String operator, int op1, int op2) {
        senderProtocol.prepareMessage(operator, op1, op2, op1/op2);
    }

    @Override
    public void close() {
        senderProtocol.close();
    }
    
}
