package es_3;

public interface INewCommandConsumer {
    void add(String operator, int op1, int op2);
    void sub(String operator, int op1, int op2);
    void mul(String operator, int op1, int op2);
    void div(String operator, int op1, int op2);
    void close();
}
