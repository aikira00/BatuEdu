package es_3;

public class NewApplication implements INewCommandConsumer{
    NewSenderProtocol senderProtocolManager;
    int result;

    public NewApplication(NewSenderProtocol senderProtocol) {
        this.senderProtocolManager = senderProtocol;
        result = 0;
    }


    @Override
    public void add(String op, int op1, int op2) {
        result = op1 + op2;
        senderProtocolManager.prepareMessage(op, op1, op2, result);
    }

    @Override
    public void sub(String op, int op1, int op2) {
        result = op1 - op2;
        senderProtocolManager.prepareMessage(op, op1, op2, result);
    }

    @Override
    public void mul(String op, int op1, int op2) {
        result = op1 * op2;
        senderProtocolManager.prepareMessage(op, op1, op2, result);
    }

    @Override
    public void div(String op, int op1, int op2) {
        result = op1 / op2;
        senderProtocolManager.prepareMessage(op, op1, op2, result);
    }

    @Override
    public void close() {
        senderProtocolManager.close();
    }
}
