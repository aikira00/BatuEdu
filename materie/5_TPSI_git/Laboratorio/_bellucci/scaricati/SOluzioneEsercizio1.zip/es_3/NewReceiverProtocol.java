package es_3;

import io.IMessageConsumer;

public class NewReceiverProtocol implements IMessageConsumer{
    private ICommandConsumer consumer;
    public NewReceiverProtocol(ICommandConsumer consumer){
        this.consumer = consumer;
    }


    @Override
    public void consumeMessage(String s) {
        if(s.equals("quit")){
            consumer.close();
            return;
        }
        String [] array=s.split("XX");
        consumer.calculate(array[1], 
                Integer.parseInt(array[0]),
                Integer.parseInt(array[2]));
        

        
    }


}
