package es_3;

import io.IMessageConsumer;
import io.Sender;
import io.Reader;
import java.io.*;
import java.net.ServerSocket;
import java.net.Socket;

public class Main {
    public static void main(String[] args) throws IOException {
        ServerSocket ss = null;
            ss = new ServerSocket(60000);
        Socket s = ss.accept();
        PrintWriter out = new PrintWriter(
                ((Socket) s).getOutputStream());
        BufferedReader in = new BufferedReader(
                new InputStreamReader(s.getInputStream()));        
        Sender sender = new Sender(out);
        Reader reader = new Reader(in, "quit");
        ISenderProtocol sp = 
                new NewSenderProtocol(sender);
        INewCommandConsumer app = new NewApp(sp);
        IMessageConsumer rp =
                new OtherReceiverProtocol(app);
        reader.setConsumer(rp);
    }
}