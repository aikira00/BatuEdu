package es_3;

import io.Sender;
public class NewSenderProtocol implements ISenderProtocol{
    private Sender sender;

    public NewSenderProtocol(Sender sender){
        this.sender = sender;
    }

    public void prepareMessage(String operator, int op1, int op2, int res){
       String message = op1 + "XX" + operator + "XX" + op2 + "XX" + "=" + "XX" + res;
       sender.send(message);
    }

    public void close(){
        sender.close();
    }
}
