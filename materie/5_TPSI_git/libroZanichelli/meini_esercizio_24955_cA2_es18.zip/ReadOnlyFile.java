
public class ReadOnlyFile extends FileException {
   public String toString() {
       return "Read-only file!";
   }
}
