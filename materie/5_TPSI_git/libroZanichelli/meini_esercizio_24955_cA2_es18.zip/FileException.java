
abstract public class FileException extends Exception {
}
