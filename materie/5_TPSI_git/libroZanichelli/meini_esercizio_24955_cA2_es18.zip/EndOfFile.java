
public class EndOfFile extends FileException {
    public String toString() {
       return "End of file!";
   }
}
