
public class WriteOnlyFile extends FileException {
    public String toString() {
      return "Write-only file!";
   }
}
